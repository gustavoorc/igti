var input1 = document.querySelector('#input1');
input1.value = 'Raphael Gomide';
