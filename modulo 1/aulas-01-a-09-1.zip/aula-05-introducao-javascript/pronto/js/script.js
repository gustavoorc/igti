console.log('JavaScript em funcionamento!');
